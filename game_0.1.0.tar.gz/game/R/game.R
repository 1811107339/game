b<-function(){
  a<-seq(0,2*pi,length.out=3600)
  r=1-sin(a)
  x1=r*cos(a)
  y1=r*sin(a)
  x2=x1+1.2
  y2=y1
  #pdf("a.pdf",width=15,height = 10)
  plot(x1,y1,col="red",xlim=c(-2,3),ylim=c(-2,1),axes=F,ann=F)
  points(x2,y2,col="red2")
  arrows(x0=-1.5,y0=-1.5,x1=2.5,y1=0.5,col="red",lwd=6)
  text(x=0.6,y=-0.9,"I love you ,forever !",col="red")
  #dev.off()
}
